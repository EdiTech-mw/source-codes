import ctypes
import threading
import time
import random
import pyaudio
import win32gui
import win32con
import win32api

# --- MessageBox via ctypes ---
def native_yesno(title, text):
    MB_YESNO = 0x04
    IDYES = 6
    return ctypes.windll.user32.MessageBoxW(0, text, title, MB_YESNO) == IDYES

def confirm_twice():
    return native_yesno("Enterwind.exe by EdiTech", "Are you sure you want to run my first malware? note:I do not know how to make destructive malwares yet") and \
           native_yesno("Enterwind.exe by EdiTech", "Are you sure?")

# --- Bytebeat Formulas ---
bytebeat_library = [
    lambda t: (t & (t >> 11) & (t >> 8)),
    lambda t: ((t >> 5 | t >> 8) ^ t),
    lambda t: (t >> 4) | (t & 123),
    lambda t: t * (t >> 5 | t >> 8),
    lambda t: (t * (t >> 11) + (t >> 5)) ^ (t >> 3),
    lambda t: (t >> 7) ^ (t >> 6) ^ (t >> 5) ^ t,
    lambda t: (t >> 12) | (t >> 8) ^ t,
    lambda t: (t & t >> 5),
    lambda t: t * t >> 10,
    lambda t: t ^ (t << 1),
    lambda t: (t * 5 & t >> 7),
    lambda t: (t >> 9) ^ (t >> 7),
    lambda t: (t & (t >> 11) & (t >> 8)),
    lambda t: (t * 3 & t >> 6) | t,
    lambda t: ((t >> 5) | (t >> 9)) + (t >> 6),
]

# --- Bytebeat Generator With Variable Hz ---
def play_bytebeat(formula_func, duration=30, rate=8000):
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paUInt8, channels=1, rate=rate, output=True)
    t = 0
    start = time.time()
    while time.time() - start < duration:
        stream.write(bytes([formula_func(t) & 255]))
        t += 1
    stream.stop_stream()
    stream.close()
    p.terminate()

# --- Visual Effects ---
def glitch_screen(duration=30):
    hdesktop = win32gui.GetDesktopWindow()
    hdc = win32gui.GetWindowDC(hdesktop)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    start = time.time()
    while time.time() - start < duration:
        x = random.randint(0, width)
        y = random.randint(0, height)
        sx = random.randint(0, width)
        sy = random.randint(0, height)
        w = random.randint(50, 200)
        h = random.randint(50, 200)
        win32gui.BitBlt(hdc, x, y, w, h, hdc, sx, sy, win32con.SRCCOPY)
        time.sleep(0.02)
    win32gui.ReleaseDC(hdesktop, hdc)

def flip_screen_upside_down(duration=30):
    hdesktop = win32gui.GetDesktopWindow()
    hdc = win32gui.GetWindowDC(hdesktop)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    start = time.time()
    while time.time() - start < duration:
        win32gui.BitBlt(hdc, 0, 0, width, height, hdc, 0, height, win32con.SRCCOPY)
        time.sleep(0.05)
    win32gui.ReleaseDC(hdesktop, hdc)

def invert_colors(duration=30):
    hdesktop = win32gui.GetDesktopWindow()
    hdc = win32gui.GetWindowDC(hdesktop)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    start = time.time()
    while time.time() - start < duration:
        win32gui.BitBlt(hdc, 0, 0, width, height, hdc, 0, 0, win32con.NOTSRCCOPY)
        time.sleep(0.05)
    win32gui.ReleaseDC(hdesktop, hdc)

def pixel_shuffle(duration=30):
    hdesktop = win32gui.GetDesktopWindow()
    hdc = win32gui.GetWindowDC(hdesktop)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    start = time.time()
    while time.time() - start < duration:
        for _ in range(20):
            x1 = random.randint(0, width)
            y1 = random.randint(0, height)
            x2 = random.randint(0, width)
            y2 = random.randint(0, height)
            win32gui.BitBlt(hdc, x1, y1, 120, 120, hdc, x2, y2, win32con.SRCCOPY)
        time.sleep(0.03)
    win32gui.ReleaseDC(hdesktop, hdc)

def screen_bounce(duration=30):
    hdesktop = win32gui.GetDesktopWindow()
    hdc = win32gui.GetWindowDC(hdesktop)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    offset = 20
    start = time.time()
    while time.time() - start < duration:
        win32gui.BitBlt(hdc, offset, offset, width - offset, height - offset, hdc, 0, 0, win32con.SRCCOPY)
        offset *= -1
        time.sleep(0.1)
    win32gui.ReleaseDC(hdesktop, hdc)

def wave_distortion(duration=30):
    hdesktop = win32gui.GetDesktopWindow()
    hdc = win32gui.GetWindowDC(hdesktop)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    start = time.time()
    while time.time() - start < duration:
        for y in range(0, height, 50):
            dx = random.randint(-30, 30)
            win32gui.BitBlt(hdc, dx, y, width, 50, hdc, 0, y, win32con.SRCCOPY)
        time.sleep(0.1)
    win32gui.ReleaseDC(hdesktop, hdc)

# --- Visual Effects Runner ---
visual_effects = [
    glitch_screen,
    flip_screen_upside_down,
    invert_colors,
    pixel_shuffle,
    screen_bounce,
    wave_distortion,
]

def run_visuals_concurrently(duration=30):
    chosen = random.sample(visual_effects, k=3)
    threads = [threading.Thread(target=effect, args=(duration,), daemon=True) for effect in chosen]
    for thread in threads: thread.start()
    for thread in threads: thread.join()

# --- Full Round Executor ---
def run_round(bytebeat_func, duration=30):
    rate = random.choice([4000, 8000, 11025, 16000])
    print(f"🎶 Bytebeat playing at {rate} Hz")
    vis_thread = threading.Thread(target=run_visuals_concurrently, args=(duration,), daemon=True)
    vis_thread.start()
    play_bytebeat(bytebeat_func, duration, rate)
    vis_thread.join()

# --- Launch Sequence ---
def launch_sequence():
    for i in range(15):
        print(f"🚀 ROUND {i+1}/15")
        bytebeat = bytebeat_library[i % len(bytebeat_library)]
        run_round(bytebeat, 30)
        time.sleep(1)

# --- Main Entry ---
if confirm_twice():
    launch_sequence()
else:
    print("🛑 Launch cancelled.")
